'use client'
import { Col, Container, Row } from 'react-bootstrap';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

const Page = () => {
  const initialValues = {
    username: '',
    password: '',
    rememberMe: false, 
  };

  const validationSchema = Yup.object().shape({
    username: Yup.string().required('Username is required'),
    password: Yup.string().required('Password is required'),
  });

  const onSubmit = (values:any) => {
    console.log("values", values);
       // axios
        //   .post("http://localhost:4500/user/login", data)
        //   .then((res) => {
        //     console.log(res.data);
        //     toast.success(res.data.message);
        //     // Reset the form here
        //   })
        //   .catch((error) => {
        //     console.log(error.response.data);
        //     toast.error(JSON.stringify(error.response.data));
        //   });  
    };

  return (
    <div>
      <Container>
        <Row>
          <Col>
            <Formik
              initialValues={initialValues}
              validationSchema={validationSchema}
              onSubmit={onSubmit}
            >
              {({ handleSubmit }) => (
                <Form onSubmit={handleSubmit}>
                  <label htmlFor="username">Username</label>
                  <Field
                    type="email"
                    name="username"
                    placeholder="Enter Username"
                    className="form-control"
                  />
                  <ErrorMessage name="username" component="div" className="error" />

                  <label htmlFor="password">Password</label>
                  <Field
                    type="password"
                    name="password"
                    placeholder="Enter Password"
                    className="form-control"
                  />
                  <ErrorMessage name="password" component="div" className="error" />

                  <div className="checkbox">
                    <label>
                      <Field type="checkbox" name="rememberMe" />
                      Remember Me
                    </label>
                  </div>

                  <div className="forgot-password">
              <a href="/forgot-password">Forgot Password?</a>
            </div>

                  <button type="submit" className="btn btn-primary">Submit</button>
                </Form>
              )}
            </Formik>
          </Col>
        </Row>
        <Row>
          <Col>
          
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default Page;
