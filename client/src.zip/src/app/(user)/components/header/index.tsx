'use client'
import Link from 'next/link'
import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'

function Header() {
  return (
    <Container fluid className="p-0">
    <Navbar collapseOnSelect expand="lg" bg="black" variant="dark" className='py-0 nav'>
      <Navbar.Brand className="app_name" href="/home">
        <img src='logo.png' height='100px' alt="Logo" className='logo'/>
      </Navbar.Brand>
      <Navbar.Toggle aria-controls="responsive-navbar-nav" />
      <Navbar.Collapse className="justify-content-end" id="responsive-navbar-nav">
        <Nav className="me-5">
          <Link href="/" className='link'>Home</Link>
          <Link href="/about" className='link'>About Us</Link>
          <Link href="/ourservices" className='link'>Service</Link>
          <Link href="/contact" className='link'>Contact Us</Link>
          <Link href="/signin" className='link'>Login</Link>
        </Nav>
      </Navbar.Collapse>
    </Navbar>
  </Container>


  
  )
}

export default Header
